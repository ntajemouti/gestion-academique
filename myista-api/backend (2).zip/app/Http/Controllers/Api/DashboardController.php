<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Absence;
use App\Models\Club;
use App\Models\Demande;
use App\Models\Filiere;
use App\Models\Groupe;
use App\Models\Module;
use App\Models\Note;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $auth = $request->user();

        return match($auth->role) {
            'Administrateur' => $this->adminStats(),
            'Formateur'      => $this->formateurStats($auth),
            'Stagiaire'      => $this->stagiaireStats($auth),
            default          => response()->json(['message' => 'Rôle inconnu.'], 400),
        };
    }

    private function adminStats(): JsonResponse
    {
        return response()->json([
            'utilisateurs' => [
                'total'        => User::count(),
                'stagiaires'   => User::where('role', 'Stagiaire')->count(),
                'formateurs'   => User::where('role', 'Formateur')->count(),
                'admins'       => User::where('role', 'Administrateur')->count(),
                'actifs'       => User::where('statut', 'Actif')->count(),
            ],
            'filieres'     => Filiere::where('statut', 'Actif')->count(),
            'modules'      => Module::count(),
            'groupes'      => Groupe::where('statut', 'Actif')->count(),
            'clubs'        => Club::where('statut', 'Actif')->count(),
            'demandes'     => [
                'total'       => Demande::count(),
                'en_attente'  => Demande::where('statut', 'En attente')->count(),
                'approuvees'  => Demande::where('statut', 'Approuvée')->count(),
                'rejetees'    => Demande::where('statut', 'Rejetée')->count(),
            ],
            'absences_semaine' => Absence::whereDate('date', '>=', now()->startOfWeek())
                                         ->whereDate('date', '<=', now()->endOfWeek())
                                         ->count(),
        ]);
    }

    private function formateurStats(User $auth): JsonResponse
    {
        $moduleIds = $auth->modulesEnseignes()->pluck('id');

        return response()->json([
            'mes_modules'   => $moduleIds->count(),
            'absences'      => [
                'total'       => Absence::where('formateur_id', $auth->id)->count(),
                'cette_semaine' => Absence::where('formateur_id', $auth->id)
                                          ->whereDate('date', '>=', now()->startOfWeek())
                                          ->whereDate('date', '<=', now()->endOfWeek())
                                          ->count(),
            ],
            'notes_saisies' => Note::where('formateur_id', $auth->id)->count(),
            'stagiaires_concernes' => Absence::where('formateur_id', $auth->id)
                                             ->distinct('stagiaire_id')
                                             ->count('stagiaire_id'),
        ]);
    }

    private function stagiaireStats(User $auth): JsonResponse
    {
        $notes    = Note::where('stagiaire_id', $auth->id)->with('module')->get();
        $absences = Absence::where('stagiaire_id', $auth->id)->get();

        $moyenneGenerale = 0;
        if ($notes->isNotEmpty()) {
            $totalPondere = $notes->sum(fn($n) => $n->note * $n->coefficient);
            $totalCoeff   = $notes->sum('coefficient');
            $moyenneGenerale = $totalCoeff > 0 ? round($totalPondere / $totalCoeff, 2) : 0;
        }

        $mention = match(true) {
            $moyenneGenerale >= 16 => 'Très Bien',
            $moyenneGenerale >= 14 => 'Bien',
            $moyenneGenerale >= 12 => 'Assez Bien',
            $moyenneGenerale >= 10 => 'Passable',
            default                => 'Insuffisant',
        };

        return response()->json([
            'moyenne_generale' => $moyenneGenerale,
            'mention'          => $mention,
            'notes_count'      => $notes->count(),
            'absences'         => [
                'total'        => $absences->count(),
                'justifiees'   => $absences->where('justifiee', true)->count(),
                'injustifiees' => $absences->where('justifiee', false)->count(),
            ],
            'demandes'         => [
                'total'       => Demande::where('user_id', $auth->id)->count(),
                'en_attente'  => Demande::where('user_id', $auth->id)->where('statut', 'En attente')->count(),
            ],
            'clubs_count'      => $auth->clubs()->count(),
            'filiere'          => $auth->filiere?->nom,
            'groupe'           => $auth->groupe?->nom,
        ]);
    }
}
