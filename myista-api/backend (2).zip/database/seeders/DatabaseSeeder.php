<?php

namespace Database\Seeders;

use App\Models\Absence;
use App\Models\Club;
use App\Models\Demande;
use App\Models\EmploiDuTemps;
use App\Models\Filiere;
use App\Models\Groupe;
use App\Models\Module;
use App\Models\Note;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // ── 1. Admin ─────────────────────────────────────────────
        $admin = User::updateOrCreate(
             ['matricule' => 'ADM001'],
             [
                'prenom' => 'Admin',
                'nom' => 'MyISTA',
                'email' => 'admin@myista.ma',
                'password' => 'password',
                'role' => 'Administrateur',
                'statut' => 'Actif',
            ]
        );

        // ── 2. Filieres ──────────────────────────────────────────
        $filDev = Filiere::create([
            'code'        => 'DEV',
            'nom'         => 'Développement Digital',
            'description' => 'Formation en développement web et mobile',
            'duree'       => 2,
            'color'       => '#2563eb',
            'statut'      => 'Actif',
        ]);

        $filInfra = Filiere::create([
            'code'        => 'INFRA',
            'nom'         => 'Infrastructure & Réseaux',
            'description' => 'Administration systèmes et réseaux',
            'duree'       => 2,
            'color'       => '#16a34a',
            'statut'      => 'Actif',
        ]);

        $filData = Filiere::create([
            'code'        => 'DATA',
            'nom'         => 'Data Science & IA',
            'description' => 'Analyse de données et intelligence artificielle',
            'duree'       => 2,
            'color'       => '#9333ea',
            'statut'      => 'Actif',
        ]);

        // ── 3. Formateurs ────────────────────────────────────────
        $form1 = User::create([
            'matricule'  => 'FOR001',
            'prenom'     => 'Karim',
            'nom'        => 'Benali',
            'email'      => 'k.benali@myista.ma',
            'password'   => Hash::make('password'),
            'role'       => 'Formateur',
            'statut'     => 'Actif',
            'specialite' => 'Développement Web',
        ]);

        $form2 = User::create([
            'matricule'  => 'FOR002',
            'prenom'     => 'Fatima',
            'nom'        => 'Zahra',
            'email'      => 'f.zahra@myista.ma',
            'password'   => Hash::make('password'),
            'role'       => 'Formateur',
            'statut'     => 'Actif',
            'specialite' => 'Réseaux & Sécurité',
        ]);

        $form3 = User::create([
            'matricule'  => 'FOR003',
            'prenom'     => 'Youssef',
            'nom'        => 'Idrissi',
            'email'      => 'y.idrissi@myista.ma',
            'password'   => Hash::make('password'),
            'role'       => 'Formateur',
            'statut'     => 'Actif',
            'specialite' => 'Data Science',
        ]);

        // ── 4. Modules ───────────────────────────────────────────
        $mod1 = Module::create(['code' => 'WEB101', 'nom' => 'Développement Web Frontend', 'filiere_id' => $filDev->id,   'formateur_id' => $form1->id, 'heures_par_semaine' => 8, 'coefficient' => 3]);
        $mod2 = Module::create(['code' => 'WEB201', 'nom' => 'Développement Backend',      'filiere_id' => $filDev->id,   'formateur_id' => $form1->id, 'heures_par_semaine' => 6, 'coefficient' => 3]);
        $mod3 = Module::create(['code' => 'MOB101', 'nom' => 'Développement Mobile',       'filiere_id' => $filDev->id,   'formateur_id' => $form1->id, 'heures_par_semaine' => 6, 'coefficient' => 2]);
        $mod4 = Module::create(['code' => 'NET101', 'nom' => 'Réseaux Fondamentaux',       'filiere_id' => $filInfra->id, 'formateur_id' => $form2->id, 'heures_par_semaine' => 8, 'coefficient' => 3]);
        $mod5 = Module::create(['code' => 'SEC101', 'nom' => 'Cybersécurité',              'filiere_id' => $filInfra->id, 'formateur_id' => $form2->id, 'heures_par_semaine' => 6, 'coefficient' => 3]);
        $mod6 = Module::create(['code' => 'DAT101', 'nom' => 'Analyse de Données',        'filiere_id' => $filData->id,  'formateur_id' => $form3->id, 'heures_par_semaine' => 8, 'coefficient' => 4]);

        // ── 5. Groupes ───────────────────────────────────────────
        $grpDev1 = Groupe::create([
            'nom'                   => 'DEV-A',
            'filiere_id'            => $filDev->id,
            'niveau'                => '1ère année',
            'annee'                 => '2024-2025',
            'formateur_referent_id' => $form1->id,
            'statut'                => 'Actif',
        ]);

        $grpInfra1 = Groupe::create([
            'nom'                   => 'INFRA-A',
            'filiere_id'            => $filInfra->id,
            'niveau'                => '1ère année',
            'annee'                 => '2024-2025',
            'formateur_referent_id' => $form2->id,
            'statut'                => 'Actif',
        ]);

        // ── 6. Stagiaires ────────────────────────────────────────
        $sta1 = User::create([
            'matricule'  => 'STA001',
            'prenom'     => 'Ahmed',
            'nom'        => 'Ouali',
            'email'      => 'a.ouali@myista.ma',
            'password'   => Hash::make('password'),
            'role'       => 'Stagiaire',
            'statut'     => 'Actif',
            'filiere_id' => $filDev->id,
            'groupe_id'  => $grpDev1->id,
        ]);

        $sta2 = User::create([
            'matricule'  => 'STA002',
            'prenom'     => 'Nadia',
            'nom'        => 'Benhaddou',
            'email'      => 'n.benhaddou@myista.ma',
            'password'   => Hash::make('password'),
            'role'       => 'Stagiaire',
            'statut'     => 'Actif',
            'filiere_id' => $filDev->id,
            'groupe_id'  => $grpDev1->id,
        ]);

        $sta3 = User::create([
            'matricule'  => 'STA003',
            'prenom'     => 'Omar',
            'nom'        => 'Tazi',
            'email'      => 'o.tazi@myista.ma',
            'password'   => Hash::make('password'),
            'role'       => 'Stagiaire',
            'statut'     => 'Actif',
            'filiere_id' => $filInfra->id,
            'groupe_id'  => $grpInfra1->id,
        ]);

        // ── 7. Notes ─────────────────────────────────────────────
        Note::create(['stagiaire_id' => $sta1->id, 'module_id' => $mod1->id, 'formateur_id' => $form1->id, 'note' => 15.5, 'coefficient' => 3, 'date_evaluation' => '2025-01-15', 'type_evaluation' => 'Contrôle']);
        Note::create(['stagiaire_id' => $sta1->id, 'module_id' => $mod2->id, 'formateur_id' => $form1->id, 'note' => 13.0, 'coefficient' => 3, 'date_evaluation' => '2025-01-20', 'type_evaluation' => 'Contrôle']);
        Note::create(['stagiaire_id' => $sta2->id, 'module_id' => $mod1->id, 'formateur_id' => $form1->id, 'note' => 17.0, 'coefficient' => 3, 'date_evaluation' => '2025-01-15', 'type_evaluation' => 'Contrôle']);
        Note::create(['stagiaire_id' => $sta3->id, 'module_id' => $mod4->id, 'formateur_id' => $form2->id, 'note' => 11.5, 'coefficient' => 3, 'date_evaluation' => '2025-01-18', 'type_evaluation' => 'Examen']);

        // ── 8. Absences ──────────────────────────────────────────
        Absence::create(['stagiaire_id' => $sta1->id, 'module_id' => $mod1->id, 'formateur_id' => $form1->id, 'date' => '2025-01-10', 'justifiee' => false]);
        Absence::create(['stagiaire_id' => $sta2->id, 'module_id' => $mod2->id, 'formateur_id' => $form1->id, 'date' => '2025-01-12', 'justifiee' => true, 'motif' => 'Maladie']);

        // ── 9. Clubs ─────────────────────────────────────────────
        $clubCode = Club::create(['nom' => 'Club Coding', 'description' => 'Hackathons et projets open source', 'responsable_id' => $form1->id, 'capacite_max' => 30, 'icon' => 'code', 'statut' => 'Actif']);
        $clubRobo = Club::create(['nom' => 'Club Robotique', 'description' => 'IoT et robotique', 'responsable_id' => $form2->id, 'capacite_max' => 20, 'icon' => 'cpu',  'statut' => 'Actif']);

        $clubCode->membres()->attach([$sta1->id, $sta2->id]);
        $clubRobo->membres()->attach([$sta3->id]);

        // ── 10. Demandes ─────────────────────────────────────────
        Demande::create(['user_id' => $sta1->id, 'type' => 'Attestation de présence', 'description' => 'Pour dossier visa', 'statut' => 'En attente']);
        Demande::create(['user_id' => $sta2->id, 'type' => 'Relevé de notes',         'description' => 'Candidature emploi',  'statut' => 'Approuvée', 'traite_par' => $admin->id, 'traite_le' => now()]);

        // ── 11. Emplois du temps ─────────────────────────────────
        EmploiDuTemps::create(['groupe_id' => $grpDev1->id, 'module_id' => $mod1->id, 'formateur_id' => $form1->id, 'jour' => 'Lundi',    'heure_debut' => '08:30', 'heure_fin' => '10:30', 'salle' => 'Labo 1']);
        EmploiDuTemps::create(['groupe_id' => $grpDev1->id, 'module_id' => $mod2->id, 'formateur_id' => $form1->id, 'jour' => 'Mardi',    'heure_debut' => '10:30', 'heure_fin' => '12:30', 'salle' => 'Salle A2']);
        EmploiDuTemps::create(['groupe_id' => $grpDev1->id, 'module_id' => $mod3->id, 'formateur_id' => $form1->id, 'jour' => 'Mercredi', 'heure_debut' => '08:30', 'heure_fin' => '10:30', 'salle' => 'Labo 2']);
        EmploiDuTemps::create(['groupe_id' => $grpInfra1->id, 'module_id' => $mod4->id, 'formateur_id' => $form2->id, 'jour' => 'Lundi',  'heure_debut' => '10:30', 'heure_fin' => '12:30', 'salle' => 'Salle B1']);
        EmploiDuTemps::create(['groupe_id' => $grpInfra1->id, 'module_id' => $mod5->id, 'formateur_id' => $form2->id, 'jour' => 'Jeudi',  'heure_debut' => '08:30', 'heure_fin' => '10:30', 'salle' => 'Salle B2']);

        $this->command->info('✅  MyISTA seed terminé — identifiants: admin@myista.ma / password');
    }
}
